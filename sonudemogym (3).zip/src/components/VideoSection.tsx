import { useEffect, useRef } from 'react';
import { motion } from 'motion/react';

export default function VideoSection() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    resize();
    window.addEventListener('resize', resize);

    const embers: any[] = [];
    for (let i = 0; i < 120; i++) {
      embers.push({
        x: Math.random() * canvas.width, y: canvas.height + Math.random() * 50,
        size: Math.random() * 4 + 1, speedY: -(Math.random() * 2 + 1),
        speedX: (Math.random() - 0.5) * 0.8, life: Math.random(),
        decay: Math.random() * 0.004 + 0.001, hue: Math.random() < 0.5 ? 0 : 20,
        wobble: Math.random() * Math.PI * 2, wobbleSpeed: Math.random() * 0.05
      });
    }

    let t = 0;
    function animate() {
      animationFrameId = requestAnimationFrame(animate);
      t++;
      ctx!.fillStyle = 'rgba(8,4,4,.15)';
      ctx!.fillRect(0, 0, canvas!.width, canvas!.height);

      for (let i = 0; i < 3; i++) {
        const ox = canvas!.width * (0.2 + i * 0.3) + Math.sin(t * 0.008 + i * 2) * 80;
        const oy = canvas!.height * 0.5 + Math.cos(t * 0.006 + i) * 60;
        const gr = ctx!.createRadialGradient(ox, oy, 0, ox, oy, 200 + i * 50);
        gr.addColorStop(0, `rgba(255,${44 + i * 20},0,0.06)`);
        gr.addColorStop(1, 'transparent');
        ctx!.fillStyle = gr; ctx!.beginPath(); ctx!.arc(ox, oy, 250 + i * 50, 0, Math.PI * 2); ctx!.fill();
      }

      embers.forEach(e => {
        e.wobble += e.wobbleSpeed;
        e.x += e.speedX + Math.sin(e.wobble) * 0.5;
        e.y += e.speedY;
        e.life -= e.decay;
        if (e.life <= 0 || e.y < -10) { e.y = canvas!.height + 10; e.x = Math.random() * canvas!.width; e.life = 1; }
        ctx!.beginPath();
        ctx!.arc(e.x, e.y, e.size, 0, Math.PI * 2);
        ctx!.fillStyle = `hsla(${e.hue},100%,65%,${e.life * 0.8})`;
        ctx!.shadowBlur = 8; ctx!.shadowColor = `hsl(${e.hue},100%,60%)`;
        ctx!.fill(); ctx!.shadowBlur = 0;
      });

      if (t % 120 === 0) {
        const lx1 = Math.random() * canvas!.width;
        const lx2 = lx1 + (Math.random() - 0.5) * 200;
        ctx!.beginPath(); ctx!.moveTo(lx1, 0); ctx!.lineTo(lx2, canvas!.height);
        ctx!.strokeStyle = 'rgba(255,80,0,.12)'; ctx!.lineWidth = 1; ctx!.stroke();
      }
    }
    animate();

    return () => {
      window.removeEventListener('resize', resize);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return (
    <section id="video-section" className="relative h-screen overflow-hidden flex items-center justify-center">
      <div className="absolute inset-0 z-0 overflow-hidden">
        <canvas ref={canvasRef} className="w-full h-full" />
      </div>
      <div className="absolute inset-0 z-10 bg-gradient-to-b from-[#0a0a0a]/70 via-[#0a0a0a]/30 to-[#0a0a0a]/90" />
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-100px" }}
        transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
        className="relative z-20 text-center px-5"
      >
        <motion.div
          animate={{ boxShadow: ['0 0 20px rgba(255,44,44,.4)', '0 0 50px rgba(255,107,0,.8)', '0 0 20px rgba(255,44,44,.4)'] }}
          transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
          className="inline-flex items-center gap-2 bg-gradient-to-br from-red to-orange px-6 py-2 mb-6 text-[0.75rem] tracking-[.3em] uppercase font-bold clip-path-btn"
        >
          🏆 Elite Training Facility
        </motion.div>
        <h2 className="font-bebas text-6xl md:text-7xl lg:text-8xl leading-[.95] tracking-[.03em] m-0 text-white">
          THE GRIND<br /><em className="not-italic text-gradient">NEVER STOPS</em>
        </h2>
        <p className="mt-6 text-white/65 text-[1.1rem] tracking-[.1em] uppercase">
          Where champions are forged in iron and will
        </p>
      </motion.div>
    </section>
  );
}
