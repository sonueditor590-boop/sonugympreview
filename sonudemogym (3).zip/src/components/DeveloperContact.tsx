import { motion } from 'motion/react';

export default function DeveloperContact() {
  return (
    <section id="developer" className="py-12 md:py-20 relative overflow-hidden bg-black border-t border-glass-border">
      <div className="max-w-[1200px] mx-auto px-5 md:px-10">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-50px" }}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          className="bg-glass border border-glass-border rounded-2xl p-8 md:p-12 text-center relative overflow-hidden group"
        >
          <div className="absolute inset-0 bg-gradient-to-br from-red/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
          
          <div className="relative z-10">
            <div className="inline-flex items-center gap-3 text-[0.7rem] tracking-[.4em] uppercase text-red font-bold mb-4">
              Website Developer
            </div>
            <h2 className="font-bebas text-4xl md:text-5xl lg:text-6xl leading-[.95] tracking-[.03em] mb-4">
              Designed & Developed by <br className="md:hidden" />
              <span className="text-gradient">Sonu</span>
            </h2>
            <p className="text-white/60 max-w-2xl mx-auto mb-8 text-sm md:text-base tracking-wide">
              Looking to build a premium, high-performance website for your business? Let's collaborate to create a digital experience that converts visitors into customers.
            </p>
            
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <a
                href="mailto:sonueditor.590@gmail.com"
                className="hover-target inline-flex items-center justify-center gap-2 px-8 py-4 bg-red text-white font-rajdhani text-base font-bold tracking-[.1em] uppercase rounded-full transition-all duration-300 hover:bg-red/80 hover:scale-105 hover:shadow-[0_0_30px_rgba(255,44,44,.4)] w-full sm:w-auto"
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/></svg>
                Email Sonu
              </a>
              <a
                href="https://wa.me/918950510445"
                target="_blank"
                rel="noreferrer"
                className="hover-target inline-flex items-center justify-center gap-2 px-8 py-4 bg-transparent border border-white/20 text-white font-rajdhani text-base font-bold tracking-[.1em] uppercase rounded-full transition-all duration-300 hover:bg-white/5 hover:border-white/40 hover:scale-105 w-full sm:w-auto"
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
                WhatsApp
              </a>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
