import { useRef } from 'react';
import { motion, useScroll, useTransform } from 'motion/react';

const transformations = [
  { name: 'Rahul M.', result: 'Lost 28kg in 5 months', image: '/download.jpg' },
  { name: 'Rajesh', result: 'Gained lean muscle + toned', image: '/download_1.jpg' },
  { name: 'Amit K.', result: '+15kg muscle mass', image: '/Fitness_Worth.jpg' },
];

function TransformationCard({ t, i }: { t: any, i: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"]
  });
  
  const y = useTransform(scrollYProgress, [0, 1], ["-10%", "10%"]);

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1], delay: i * 0.1 }}
      className="hover-target relative overflow-hidden border border-glass-border rounded transition-all duration-400 ease-[cubic-bezier(.16,1,.3,1)] h-[380px] group hover:-translate-y-2 hover:scale-[1.02] hover:shadow-[0_30px_80px_rgba(255,44,44,.25)]"
    >
      <div className="p-4 absolute top-0 left-0 right-0 bg-gradient-to-b from-black/80 to-transparent z-20">
        <div className="font-bebas text-[1.3rem] tracking-[.05em]">{t.name}</div>
        <div className="text-[0.75rem] text-orange tracking-[.1em] uppercase font-semibold">{t.result}</div>
      </div>
      <motion.img 
        style={{ y, scale: 1.1 }}
        src={t.image} 
        alt={t.name} 
        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-125 origin-center" 
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent z-10 pointer-events-none" />
    </motion.div>
  );
}

export default function Transformations() {
  return (
    <section id="transformations" className="py-20 md:py-[120px] relative overflow-hidden bg-black">
      <div className="max-w-[1200px] mx-auto px-5 md:px-10">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          className="text-center"
        >
          <div className="inline-flex items-center gap-3 text-[0.7rem] tracking-[.4em] uppercase text-red font-bold mb-4 before:content-[''] before:w-6 before:h-[1px] before:bg-red before:shadow-[0_0_6px_#ff2c2c]">Real Results</div>
          <h2 className="font-bebas text-5xl md:text-6xl lg:text-7xl leading-[.95] tracking-[.03em] mb-6">
            Real<br /><em className="not-italic text-gradient">Transformations</em>
          </h2>
        </motion.div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-16">
          {transformations.map((t, i) => (
            <TransformationCard key={i} t={t} i={i} />
          ))}
        </div>
      </div>
    </section>
  );
}
