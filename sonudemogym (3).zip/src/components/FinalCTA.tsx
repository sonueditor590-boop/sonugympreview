import { motion } from 'motion/react';

export default function FinalCTA() {
  return (
    <section id="final-cta" className="relative overflow-hidden py-[100px] md:py-[160px] text-center bg-[radial-gradient(ellipse_at_center,rgba(255,44,44,.12)_0%,#0a0a0a_70%)] before:content-[''] before:absolute before:inset-0 before:bg-[radial-gradient(ellipse_60%_40%_at_50%_50%,rgba(255,107,0,.06),transparent),radial-gradient(ellipse_40%_60%_at_30%_30%,rgba(255,44,44,.08),transparent),radial-gradient(ellipse_40%_60%_at_70%_70%,rgba(255,44,44,.06),transparent)]">
      <div className="max-w-[1200px] mx-auto px-5 md:px-10">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          className="relative z-10"
        >
          <div className="inline-flex items-center justify-center gap-3 text-[0.7rem] tracking-[.4em] uppercase text-red font-bold mb-4 before:content-[''] before:w-6 before:h-[1px] before:bg-red before:shadow-[0_0_6px_#ff2c2c] after:content-[''] after:w-6 after:h-[1px] after:bg-red after:shadow-[0_0_6px_#ff2c2c]">Limited Spots Available</div>
          <h2 className="font-bebas text-5xl md:text-6xl lg:text-7xl leading-[.95] mb-6">
            Start Your<br /><em className="not-italic text-gradient">Fitness Journey</em><br />Today
          </h2>
          <p className="text-white/55 text-[1.1rem] tracking-[.08em] mb-12 uppercase">
            Transform Your Body, Upgrade Your Life
          </p>
          <a
            href="https://wa.me/918950510445?text=Hi%20I%20want%20to%20join%20the%20gym"
            target="_blank"
            rel="noreferrer"
            className="hover-target w-full md:w-auto justify-center inline-flex items-center gap-3.5 px-8 md:px-14 py-5 bg-gradient-to-br from-[#25d366] to-[#128c3e] text-white no-underline font-rajdhani text-base md:text-[1.1rem] font-bold tracking-[.15em] uppercase clip-path-wa transition-all duration-300 animate-[wa-pulse_3s_ease-in-out_infinite] hover:-translate-y-1 hover:scale-105 hover:brightness-110"
          >
            <span className="text-[1.4rem]">💬</span>
            Join on WhatsApp Now
          </a>
        </motion.div>
      </div>
    </section>
  );
}
