import React, { useRef } from 'react';
import { motion } from 'motion/react';

const services = [
  { icon: '🏋️', title: 'Weight Training', desc: 'Heavy iron, serious gains. Our Olympic-grade weight floor is built for warriors who want maximum strength and muscle.', tag: 'Most Popular' },
  { icon: '🎯', title: 'Personal Training', desc: '1-on-1 sessions with certified coaches who design custom programs tailored to your exact goals and body type.', tag: 'Premium' },
  { icon: '🔥', title: 'Cardio Zone', desc: 'High-performance treadmills, cycles, and rowing machines backed by heart rate tech for precision fat burn.', tag: 'All Levels' },
  { icon: '⚡', title: 'Fat Loss Programs', desc: 'Scientifically-designed protocols combining HIIT, nutrition plans, and metabolic training to shred fat fast.', tag: 'Results Guaranteed' },
];

function ServiceCard({ service, index }: { service: any, index: number, key?: React.Key }) {
  const cardRef = useRef<HTMLDivElement>(null);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;
    const r = cardRef.current.getBoundingClientRect();
    const xPct = (e.clientX - r.left) / r.width - 0.5;
    const yPct = (e.clientY - r.top) / r.height - 0.5;
    cardRef.current.style.transform = `translateY(-12px) rotateX(${-yPct * 8}deg) rotateY(${xPct * 8}deg) scale(1.02)`;
  };

  const handleMouseLeave = () => {
    if (!cardRef.current) return;
    cardRef.current.style.transform = '';
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1], delay: index * 0.1 }}
      ref={cardRef}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      className="hover-target bg-glass p-10 clip-path-card relative overflow-hidden transition-all duration-400 ease-[cubic-bezier(.16,1,.3,1)] hover:shadow-[0_30px_80px_rgba(255,44,44,.2),0_0_0_1px_rgba(255,44,44,.3)] hover:border-red/40 group"
    >
      <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-red to-orange opacity-0 transition-opacity duration-400 group-hover:opacity-100" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_50%_0%,rgba(255,44,44,.08),transparent_60%)] opacity-0 transition-opacity duration-400 group-hover:opacity-100" />
      
      <motion.span
        animate={{ y: [0, -8, 0] }}
        transition={{ duration: 3, repeat: Infinity, ease: "easeInOut", delay: index * 0.5 }}
        className="text-[2.8rem] mb-5 drop-shadow-[0_0_8px_#ff2c2c] block"
      >
        {service.icon}
      </motion.span>
      <div className="font-bebas text-[1.8rem] tracking-[.05em] mb-3">{service.title}</div>
      <p className="text-white/55 text-[0.95rem] leading-[1.8]">{service.desc}</p>
      <div className="inline-block mt-5 px-3.5 py-1 text-[0.65rem] tracking-[.25em] uppercase font-bold border border-red/35 text-red">
        {service.tag}
      </div>
    </motion.div>
  );
}

export default function Services() {
  return (
    <section id="services" className="py-20 md:py-[120px] relative overflow-hidden bg-gradient-to-b from-black to-[#0f0606]">
      <div className="max-w-[1200px] mx-auto px-5 md:px-10">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          className="text-center"
        >
          <div className="inline-flex items-center gap-3 text-[0.7rem] tracking-[.4em] uppercase text-red font-bold mb-4 before:content-[''] before:w-6 before:h-[1px] before:bg-red before:shadow-[0_0_6px_#ff2c2c]">What We Offer</div>
          <h2 className="font-bebas text-5xl md:text-6xl lg:text-7xl leading-[.95] tracking-[.03em] mb-6">
            World-Class<br /><em className="not-italic text-gradient">Programs</em>
          </h2>
        </motion.div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mt-16">
          {services.map((service, i) => (
            <ServiceCard key={i} service={service} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
}
