import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';

export default function Loader() {
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setLoading(false);
    }, 2200);
    return () => clearTimeout(timer);
  }, []);

  return (
    <AnimatePresence>
      {loading && (
        <motion.div
          initial={{ opacity: 1 }}
          exit={{ opacity: 0, visibility: 'hidden' }}
          transition={{ duration: 0.7, ease: "easeInOut" }}
          className="fixed inset-0 bg-black z-[99998] flex flex-col items-center justify-center"
        >
          <motion.div
            animate={{ filter: ['drop-shadow(0 0 8px #ff2c2c)', 'drop-shadow(0 0 28px #ff6b00)'] }}
            transition={{ duration: 1.2, repeat: Infinity, repeatType: 'reverse', ease: 'easeInOut' }}
            className="font-bebas text-[clamp(3rem,8vw,6rem)] tracking-[.2em] text-gradient"
          >
            SonuDemoGym
          </motion.div>
          <div className="w-[220px] h-[2px] bg-white/10 mt-7 rounded-sm overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: '100%' }}
              transition={{ duration: 2, ease: "easeOut" }}
              className="h-full bg-gradient-to-r from-red to-orange shadow-[0_0_12px_#ff2c2c]"
            />
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
