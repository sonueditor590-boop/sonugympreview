import { motion, useScroll, useTransform } from 'motion/react';
import { useEffect, useState, useRef } from 'react';

function Counter({ target, suffix = '' }: { target: number, suffix?: string }) {
  const [count, setCount] = useState(0);
  const ref = useRef(null);
  const [hasAnimated, setHasAnimated] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !hasAnimated) {
          setHasAnimated(true);
          let startTimestamp: number;
          const duration = 1800;
          const step = (timestamp: number) => {
            if (!startTimestamp) startTimestamp = timestamp;
            const progress = Math.min((timestamp - startTimestamp) / duration, 1);
            const ease = 1 - Math.pow(1 - progress, 3);
            setCount(Math.floor(ease * target));
            if (progress < 1) {
              window.requestAnimationFrame(step);
            }
          };
          window.requestAnimationFrame(step);
        }
      },
      { threshold: 0.5 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [target, hasAnimated]);

  return <div ref={ref} className="font-bebas text-5xl md:text-6xl lg:text-7xl text-gradient leading-none drop-shadow-[0_0_20px_rgba(255,107,0,.4)]">{count}{suffix}</div>;
}

export default function About() {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start end", "end start"]
  });
  
  const y1 = useTransform(scrollYProgress, [0, 1], [50, -50]);
  const y2 = useTransform(scrollYProgress, [0, 1], [-50, 50]);

  return (
    <section id="about" ref={containerRef} className="py-20 md:py-[120px] relative overflow-hidden bg-black">
      <div className="max-w-[1200px] mx-auto px-10">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-10 md:gap-20 items-center">
          <motion.div
            style={{ y: y1 }}
            initial={{ opacity: 0, x: -60 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          >
            <div className="inline-flex items-center gap-3 text-[0.7rem] tracking-[.4em] uppercase text-red font-bold mb-4 before:content-[''] before:w-6 before:h-[1px] before:bg-red before:shadow-[0_0_6px_#ff2c2c]">Our Story</div>
            <h2 className="font-bebas text-5xl md:text-6xl lg:text-7xl leading-[.95] tracking-[.03em] mb-6">
              We Don't Just<br /><em className="not-italic text-gradient">Train Bodies</em>
            </h2>
            <p className="text-white/65 leading-[1.9] text-[1.05rem] mb-4">
              At <strong className="text-white">SonuDemoGym</strong>, we believe transformation is more than lifting weights — it's a complete lifestyle upgrade. Our state-of-the-art facility combines cutting-edge equipment with world-class coaching.
            </p>
            <p className="text-white/65 leading-[1.9] text-[1.05rem] mb-4">
              Every rep, every set, every session is designed to push you beyond your limits and unlock the athlete within you. <strong className="text-white">This is where legends are built.</strong>
            </p>
            <div className="flex gap-7 md:gap-12 mt-12 flex-wrap">
              <div className="text-left">
                <Counter target={2500} suffix="+" />
                <div className="text-[0.75rem] tracking-[.25em] uppercase text-white/45 mt-1">Members</div>
              </div>
              <div className="text-left">
                <Counter target={15} suffix="+" />
                <div className="text-[0.75rem] tracking-[.25em] uppercase text-white/45 mt-1">Expert Trainers</div>
              </div>
              <div className="text-left">
                <Counter target={98} suffix="%" />
                <div className="text-[0.75rem] tracking-[.25em] uppercase text-white/45 mt-1">Success Rate</div>
              </div>
              <div className="text-left">
                <Counter target={7} suffix="+" />
                <div className="text-[0.75rem] tracking-[.25em] uppercase text-white/45 mt-1">Years Strong</div>
              </div>
            </div>
          </motion.div>
          
          <motion.div
            style={{ y: y2 }}
            initial={{ opacity: 0, x: 60 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
            className="relative h-[280px] md:h-[500px] flex items-center justify-center"
          >
            <motion.div
              animate={{ y: [-20, 20, -20], rotate: [0, 5, 0] }}
              transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
              className="w-[300px] h-[300px] rounded-full bg-[radial-gradient(circle_at_35%_35%,rgba(255,107,0,.3),rgba(255,44,44,.2)_50%,transparent_70%)] border border-red/20 shadow-[0_0_80px_rgba(255,44,44,.2),inset_0_0_60px_rgba(255,107,0,.1)] relative flex items-center justify-center"
            >
              {[0, 0.7, 1.4].map((delay, i) => (
                <motion.div
                  key={i}
                  animate={{ scale: [1, 1.04, 1], opacity: [1, 0.5, 1] }}
                  transition={{ duration: 4, repeat: Infinity, ease: "easeInOut", delay }}
                  className={`absolute rounded-full border ${i===0?'inset-[-60px] border-red/10':i===1?'inset-[-120px] border-orange/10':'inset-[-180px] border-red/5'}`}
                />
              ))}
              <div className="font-bebas text-5xl tracking-[.1em] text-gradient-white-red text-center leading-[1.1]">
                PRO<br />LEVEL
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
