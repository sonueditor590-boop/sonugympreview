import { useEffect, useRef } from 'react';
import { motion } from 'motion/react';

export default function Hero() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    resize();
    window.addEventListener('resize', resize);

    const PARTICLE_COUNT = 180;
    const particles: any[] = [];

    class Particle {
      x!: number; y!: number; size!: number; speedX!: number; speedY!: number;
      life!: number; decay!: number; hue!: number; sat!: number;
      trail!: {x: number, y: number}[]; maxTrail!: number;

      constructor() { this.reset(); }
      reset() {
        this.x = Math.random() * canvas!.width;
        this.y = Math.random() * canvas!.height;
        this.size = Math.random() * 2.5 + 0.5;
        this.speedX = (Math.random() - 0.5) * 0.6;
        this.speedY = -(Math.random() * 0.8 + 0.2);
        this.life = 1;
        this.decay = Math.random() * 0.006 + 0.002;
        this.hue = Math.random() < 0.6 ? 0 : 20;
        this.sat = 80 + Math.random() * 20;
        this.trail = [];
        this.maxTrail = 8;
      }
      update() {
        this.trail.push({ x: this.x, y: this.y });
        if (this.trail.length > this.maxTrail) this.trail.shift();
        this.x += this.speedX + Math.sin(Date.now() * 0.0005 + this.y * 0.01) * 0.3;
        this.y += this.speedY;
        this.life -= this.decay;
        if (this.life <= 0 || this.y < -10 || this.x < -10 || this.x > canvas!.width + 10) this.reset();
      }
      draw() {
        if (this.trail.length > 1) {
          for (let i = 1; i < this.trail.length; i++) {
            const t = i / this.trail.length;
            ctx!.beginPath();
            ctx!.strokeStyle = `hsla(${this.hue},${this.sat}%,60%,${this.life * t * 0.3})`;
            ctx!.lineWidth = this.size * t;
            ctx!.moveTo(this.trail[i - 1].x, this.trail[i - 1].y);
            ctx!.lineTo(this.trail[i].x, this.trail[i].y);
            ctx!.stroke();
          }
        }
        ctx!.beginPath();
        ctx!.arc(this.x, this.y, this.size, 0, Math.PI * 2);
        ctx!.fillStyle = `hsla(${this.hue},${this.sat}%,70%,${this.life})`;
        ctx!.fill();
        ctx!.shadowBlur = 12; ctx!.shadowColor = `hsl(${this.hue},100%,60%)`;
        ctx!.fill(); ctx!.shadowBlur = 0;
      }
    }

    for (let i = 0; i < PARTICLE_COUNT; i++) {
      const p = new Particle();
      p.y = Math.random() * canvas.height;
      p.life = Math.random();
      particles.push(p);
    }

    const shapes: any[] = [];
    for (let i = 0; i < 12; i++) {
      shapes.push({
        x: Math.random() * canvas.width, y: Math.random() * canvas.height,
        size: Math.random() * 30 + 15, speed: Math.random() * 0.3 + 0.1,
        alpha: Math.random() * 0.15 + 0.05, rot: Math.random() * Math.PI * 2,
        rotSpeed: (Math.random() - 0.5) * 0.01,
        type: Math.floor(Math.random() * 3)
      });
    }

    function drawShape(s: any) {
      ctx!.save(); ctx!.translate(s.x, s.y); ctx!.rotate(s.rot);
      ctx!.globalAlpha = s.alpha; ctx!.strokeStyle = 'rgba(255,44,44,.8)'; ctx!.lineWidth = 1.5;
      if (s.type === 0) {
        ctx!.beginPath(); ctx!.moveTo(-s.size, 0); ctx!.lineTo(s.size, 0); ctx!.stroke();
        [[s.size, 0], [-s.size, 0]].forEach(([cx2, cy2]) => {
          ctx!.beginPath(); ctx!.arc(cx2, cy2, s.size * 0.35, 0, Math.PI * 2); ctx!.stroke();
        });
      } else if (s.type === 1) {
        ctx!.beginPath();
        for (let i = 0; i < 6; i++) {
          const angle = i * Math.PI / 3;
          i === 0 ? ctx!.moveTo(Math.cos(angle) * s.size, Math.sin(angle) * s.size) : ctx!.lineTo(Math.cos(angle) * s.size, Math.sin(angle) * s.size);
        }
        ctx!.closePath(); ctx!.stroke();
      } else {
        ctx!.beginPath();
        ctx!.moveTo(0, -s.size); ctx!.lineTo(s.size * 0.6, 0);
        ctx!.lineTo(0, s.size); ctx!.lineTo(-s.size * 0.6, 0); ctx!.closePath(); ctx!.stroke();
      }
      ctx!.restore(); ctx!.globalAlpha = 1;
    }

    let mouseX = canvas.width / 2, mouseY = canvas.height / 2;
    const onMouseMove = (e: MouseEvent) => { mouseX = e.clientX; mouseY = e.clientY; };
    window.addEventListener('mousemove', onMouseMove);

    function drawGrid() {
      ctx!.strokeStyle = 'rgba(255,44,44,.04)';
      ctx!.lineWidth = 1;
      const spacing = 80;
      for (let x = 0; x < canvas!.width; x += spacing) { ctx!.beginPath(); ctx!.moveTo(x, 0); ctx!.lineTo(x, canvas!.height); ctx!.stroke(); }
      for (let y = 0; y < canvas!.height; y += spacing) { ctx!.beginPath(); ctx!.moveTo(0, y); ctx!.lineTo(canvas!.width, y); ctx!.stroke(); }
    }

    let t = 0;
    function animate() {
      animationFrameId = requestAnimationFrame(animate);
      t++;
      ctx!.fillStyle = 'rgba(10,10,10,.25)';
      ctx!.fillRect(0, 0, canvas!.width, canvas!.height);

      drawGrid();

      for (let i = 0; i < 3; i++) {
        const radius = (t * 1.2 + i * 120) % 600;
        const alpha = (1 - radius / 600) * 0.08;
        ctx!.beginPath();
        ctx!.arc(mouseX, mouseY, radius, 0, Math.PI * 2);
        ctx!.strokeStyle = `rgba(255,${44 + i * 30},0,${alpha})`;
        ctx!.lineWidth = 1; ctx!.stroke();
      }

      particles.forEach(p => { p.update(); p.draw(); });
      shapes.forEach(s => {
        s.y -= s.speed; s.rot += s.rotSpeed;
        if (s.y < -50) { s.y = canvas!.height + 50; s.x = Math.random() * canvas!.width; }
        drawShape(s);
      });

      const scanY = (t * 2) % canvas!.height;
      const sg = ctx!.createLinearGradient(0, scanY - 40, 0, scanY + 40);
      sg.addColorStop(0, 'transparent'); sg.addColorStop(0.5, 'rgba(255,44,44,.04)'); sg.addColorStop(1, 'transparent');
      ctx!.fillStyle = sg; ctx!.fillRect(0, scanY - 40, canvas!.width, 80);
    }
    animate();

    return () => {
      window.removeEventListener('resize', resize);
      window.removeEventListener('mousemove', onMouseMove);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  useEffect(() => {
    const handleScroll = () => {
      const sy = window.scrollY;
      if (contentRef.current) {
        contentRef.current.style.transform = `translateY(${sy * 0.3}px)`;
      }
      const overlay = document.getElementById('hero-overlay');
      if (overlay) {
        overlay.style.opacity = Math.min(0.9, 0.15 + sy * 0.0008).toString();
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <section id="hero" className="relative h-screen w-full flex items-center justify-center overflow-hidden">
      <canvas ref={canvasRef} className="absolute inset-0 z-0" />
      <div id="hero-overlay" className="absolute inset-0 z-10 bg-[radial-gradient(ellipse_at_center,rgba(10,10,10,0)_0%,rgba(10,10,10,.75)_100%),linear-gradient(to_bottom,rgba(10,10,10,.2)_0%,rgba(10,10,10,.85)_100%)]" />
      
      <motion.div
        ref={contentRef}
        initial={{ opacity: 0, y: 60, scale: 0.95, filter: 'blur(12px)' }}
        animate={{ opacity: 1, y: 0, scale: 1, filter: 'blur(0)' }}
        transition={{ duration: 1.4, ease: [0.16, 1, 0.3, 1], delay: 2.2 }}
        className="relative z-20 text-center px-5"
      >
        <div className="inline-flex items-center gap-2.5 text-xs tracking-[.35em] uppercase text-red font-bold mb-5 before:content-[''] before:w-[30px] before:h-[1px] before:bg-red after:content-[''] after:w-[30px] after:h-[1px] after:bg-red">
          Premium Fitness Experience
        </div>
        <h1 className="font-bebas text-6xl sm:text-7xl md:text-8xl lg:text-[9rem] leading-[.92] tracking-[.03em] uppercase">
          <span className="block text-white">Build Your</span>
          <span className="block text-gradient drop-shadow-[0_0_40px_rgba(255,107,0,.6)]">Dream Physique</span>
        </h1>
        <p className="text-base md:text-lg lg:text-xl text-white/65 tracking-[.1em] my-6 mx-auto font-medium uppercase max-w-[520px]">
          Join the most advanced fitness experience
        </p>
        <div className="flex flex-col md:flex-row gap-4 justify-center items-center w-full">
          <a
            href="https://wa.me/918950510445?text=Hi%20I%20want%20to%20join%20the%20gym"
            target="_blank"
            rel="noreferrer"
            className="hover-target w-full md:w-auto justify-center inline-flex items-center gap-2.5 px-8 md:px-11 py-4 bg-gradient-to-br from-red to-orange text-white font-rajdhani text-base md:text-lg font-bold tracking-[.14em] uppercase no-underline clip-path-btn-lg shadow-[0_0_40px_rgba(255,44,44,.5),0_0_80px_rgba(255,107,0,.2)] transition-all duration-300 relative overflow-hidden hover:-translate-y-[3px] hover:scale-105 hover:brightness-115 hover:shadow-[0_0_60px_rgba(255,44,44,.7),0_0_100px_rgba(255,107,0,.3)] group"
          >
            <span className="absolute inset-0 bg-gradient-to-br from-white/15 to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100"></span>
            💪 Join Now
          </a>
          <a
            href="#services"
            className="hover-target w-full md:w-auto justify-center inline-flex items-center gap-2.5 px-8 md:px-9 py-[15px] bg-glass text-white font-rajdhani text-base md:text-lg font-semibold tracking-[.1em] uppercase no-underline clip-path-btn-lg transition-all duration-300 hover:-translate-y-[2px] hover:border-red/50 hover:bg-red/10"
          >
            Explore Programs
          </a>
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20, x: '-50%' }}
        animate={{ opacity: 1, y: 0, x: '-50%' }}
        transition={{ duration: 1, delay: 4 }}
        className="absolute bottom-8 left-1/2 z-20 flex flex-col items-center gap-2"
      >
        <span className="text-[0.65rem] tracking-[.3em] uppercase text-white/40">Scroll</span>
        <motion.div
          animate={{ opacity: [0.3, 1, 0.3], scaleY: [0.5, 1, 0.5] }}
          transition={{ duration: 1.8, repeat: Infinity, ease: "easeInOut" }}
          className="w-[1px] h-[50px] bg-gradient-to-b from-red/80 to-transparent origin-top"
        />
      </motion.div>
    </section>
  );
}
