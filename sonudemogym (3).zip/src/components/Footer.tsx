export default function Footer() {
  return (
    <footer className="p-10 text-center border-t border-glass-border text-white/30 text-[0.85rem] tracking-[.1em]">
      <div>© 2025 <span className="text-red">SonuDemoGym</span>. Transform Your Body, Upgrade Your Life.</div>
      <div className="mt-2 text-[0.75rem]">Built for Champions &nbsp;•&nbsp; All Rights Reserved</div>
    </footer>
  );
}
