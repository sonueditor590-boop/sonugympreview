import React, { useRef } from 'react';
import { motion } from 'motion/react';

const reasons = [
  { icon: '🏆', title: 'Elite Equipment', text: 'Olympic-grade machines and free weights for every training need' },
  { icon: '🎯', title: 'Expert Coaches', text: 'Certified trainers with proven track records of client transformation' },
  { icon: '🧬', title: 'Science-Based', text: 'Every program is built on sports science and nutritional expertise' },
  { icon: '🌙', title: 'Open All Day', text: 'Flexible hours to match your lifestyle — early birds and night owls welcome' },
  { icon: '🤝', title: 'Community', text: 'Join a tribe of motivated individuals pushing each other to be better' },
  { icon: '📊', title: 'Progress Tracking', text: 'Regular assessments and body composition analysis to keep you on track' },
];

function WhyItem({ item, index }: { item: any, index: number, key?: React.Key }) {
  const cardRef = useRef<HTMLDivElement>(null);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;
    const r = cardRef.current.getBoundingClientRect();
    const xPct = (e.clientX - r.left) / r.width - 0.5;
    const yPct = (e.clientY - r.top) / r.height - 0.5;
    cardRef.current.style.transform = `translateY(-8px) rotateX(${-yPct * 8}deg) rotateY(${xPct * 8}deg)`;
  };

  const handleMouseLeave = () => {
    if (!cardRef.current) return;
    cardRef.current.style.transform = '';
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1], delay: index * 0.1 }}
      ref={cardRef}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      className="hover-target text-center py-10 px-6 border border-glass-border bg-glass transition-all duration-400 relative overflow-hidden group hover:border-red/30 hover:shadow-[0_20px_60px_rgba(255,44,44,.15)]"
    >
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-0 h-[2px] bg-gradient-to-r from-red to-orange transition-all duration-500 ease-out group-hover:w-[80%]" />
      <span className="text-[2.5rem] mb-4 block drop-shadow-[0_0_8px_#ff2c2c]">{item.icon}</span>
      <div className="font-bebas text-[1.4rem] tracking-[.05em] mb-2">{item.title}</div>
      <p className="text-white/55 text-[0.9rem] leading-[1.8]">{item.text}</p>
    </motion.div>
  );
}

export default function WhyUs() {
  return (
    <section id="why-us" className="py-20 md:py-[120px] relative overflow-hidden bg-gradient-to-b from-[#0f0606] to-black">
      <div className="max-w-[1200px] mx-auto px-5 md:px-10">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          className="text-center"
        >
          <div className="inline-flex items-center gap-3 text-[0.7rem] tracking-[.4em] uppercase text-red font-bold mb-4 before:content-[''] before:w-6 before:h-[1px] before:bg-red before:shadow-[0_0_6px_#ff2c2c]">The Difference</div>
          <h2 className="font-bebas text-5xl md:text-6xl lg:text-7xl leading-[.95] tracking-[.03em] mb-6">
            Why Choose<br /><em className="not-italic text-gradient">SonuDemoGym</em>
          </h2>
        </motion.div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 mt-16">
          {reasons.map((item, i) => (
            <WhyItem key={i} item={item} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
}
