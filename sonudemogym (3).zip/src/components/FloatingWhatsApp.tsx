export default function FloatingWhatsApp() {
  return (
    <a
      href="https://wa.me/918950510445?text=Hi%20I%20want%20to%20join%20the%20gym"
      target="_blank"
      rel="noreferrer"
      className="hover-target fixed bottom-8 right-8 z-[9000] w-[60px] h-[60px] rounded-full bg-gradient-to-br from-[#25d366] to-[#128c3e] flex items-center justify-center text-[1.8rem] no-underline shadow-[0_0_30px_rgba(37,211,102,.5),0_10px_40px_rgba(0,0,0,.4)] animate-[floatWa_3s_ease-in-out_infinite] transition-all duration-300 hover:scale-110 hover:shadow-[0_0_50px_rgba(37,211,102,.8)] group"
    >
      💬
      <span className="absolute right-[72px] top-1/2 -translate-y-1/2 bg-black/80 border border-[#25d366]/30 text-white px-3.5 py-2 rounded text-[0.8rem] whitespace-nowrap font-rajdhani tracking-[.08em] font-semibold pointer-events-none opacity-0 transition-opacity duration-300 group-hover:opacity-100">
        Chat with us!
      </span>
    </a>
  );
}
