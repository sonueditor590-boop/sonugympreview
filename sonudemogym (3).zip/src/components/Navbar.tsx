import { useEffect, useState } from 'react';

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 60);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`fixed top-0 w-full z-[1000] px-4 md:px-15 py-4 md:py-5 flex items-center justify-between transition-all duration-400 ${scrolled ? 'backdrop-blur-xl bg-[#0a0a0a]/85 border-b border-glass-border' : 'bg-gradient-to-b from-black/90 to-transparent backdrop-blur-none'}`}>
      <div className="font-bebas text-2xl md:text-3xl tracking-[.15em] text-gradient-white-red">SonuDemoGym</div>
      <ul className="hidden md:flex gap-9 list-none">
        {['About', 'Services', 'Results', 'Transformations', 'Contact'].map((item) => (
          <li key={item}>
            <a
              href={`#${item.toLowerCase() === 'results' ? 'video-section' : item.toLowerCase()}`}
              className="text-white/70 no-underline text-sm tracking-[.12em] uppercase font-semibold transition-colors duration-300 relative group hover:text-white"
            >
              {item}
              <span className="absolute -bottom-1 left-0 w-0 h-[1px] bg-red transition-all duration-300 group-hover:w-full"></span>
            </a>
          </li>
        ))}
      </ul>
      <a
        href="https://wa.me/918950510445?text=Hi%20I%20want%20to%20join%20the%20gym"
        target="_blank"
        rel="noreferrer"
        className="hover-target px-4 py-2 md:px-7 md:py-2.5 bg-gradient-to-br from-red to-orange border-none text-white font-rajdhani text-xs md:text-sm font-bold tracking-[.1em] uppercase cursor-none no-underline clip-path-btn transition-all duration-300 shadow-[0_0_20px_rgba(255,44,44,0.4)] hover:brightness-125 hover:-translate-y-[1px]"
      >
        Join Now
      </a>
    </nav>
  );
}
