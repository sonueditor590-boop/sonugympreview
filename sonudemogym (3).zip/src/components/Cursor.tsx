import { useEffect, useRef } from 'react';

export default function Cursor() {
  const cursorRef = useRef<HTMLDivElement>(null);
  const dotRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const cursor = cursorRef.current;
    const dot = dotRef.current;
    if (!cursor || !dot) return;

    let mx = 0, my = 0, cx = 0, cy = 0;
    let animationFrameId: number;

    const onMouseMove = (e: MouseEvent) => {
      mx = e.clientX;
      my = e.clientY;
      dot.style.left = `${mx - 2.5}px`;
      dot.style.top = `${my - 2.5}px`;
    };

    const animateCursor = () => {
      cx += (mx - cx) * 0.14;
      cy += (my - cy) * 0.14;
      cursor.style.left = `${cx - 8}px`;
      cursor.style.top = `${cy - 8}px`;
      animationFrameId = requestAnimationFrame(animateCursor);
    };

    document.addEventListener('mousemove', onMouseMove);
    animateCursor();

    const handleMouseEnter = () => {
      cursor.style.transform = 'scale(2.4)';
      cursor.style.background = 'rgba(255, 44, 44, 0.6)';
    };
    const handleMouseLeave = () => {
      cursor.style.transform = 'scale(1)';
      cursor.style.background = 'transparent';
    };

    const addHoverListeners = () => {
      document.querySelectorAll('a, button, .hover-target').forEach(el => {
        el.addEventListener('mouseenter', handleMouseEnter);
        el.addEventListener('mouseleave', handleMouseLeave);
      });
    };

    // Initial attachment
    addHoverListeners();

    // Re-attach on DOM mutations (simple approach)
    const observer = new MutationObserver(() => {
      addHoverListeners();
    });
    observer.observe(document.body, { childList: true, subtree: true });

    return () => {
      document.removeEventListener('mousemove', onMouseMove);
      cancelAnimationFrame(animationFrameId);
      observer.disconnect();
      document.querySelectorAll('a, button, .hover-target').forEach(el => {
        el.removeEventListener('mouseenter', handleMouseEnter);
        el.removeEventListener('mouseleave', handleMouseLeave);
      });
    };
  }, []);

  return (
    <>
      <div id="cursor" ref={cursorRef}></div>
      <div id="cursor-dot" ref={dotRef}></div>
    </>
  );
}
