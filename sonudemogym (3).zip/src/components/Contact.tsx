import { motion } from 'motion/react';

export default function Contact() {
  return (
    <section id="contact" className="py-20 md:py-[120px] relative overflow-hidden bg-black">
      <div className="max-w-[1200px] mx-auto px-5 md:px-10">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-10 md:gap-20 items-start">
          <motion.div
            initial={{ opacity: 0, x: -60 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          >
            <div className="inline-flex items-center gap-3 text-[0.7rem] tracking-[.4em] uppercase text-red font-bold mb-4 before:content-[''] before:w-6 before:h-[1px] before:bg-red before:shadow-[0_0_6px_#ff2c2c]">Get In Touch</div>
            <h2 className="font-bebas text-5xl md:text-6xl lg:text-7xl leading-[.95] tracking-[.03em] mb-6">
              Start Your<br /><em className="not-italic text-gradient">Journey</em>
            </h2>
            <p className="text-white/60 leading-[2] text-[1rem] mb-8">
              Ready to transform? Reach out and one of our coaches will craft a personalized plan for you.
            </p>
            <div className="flex items-center gap-3 mb-4 text-white/70 text-[1rem]">
              <span className="text-[1.2rem]">📍</span><span>yASHODHARA, 6, rangpur</span>
            </div>
            <div className="flex items-center gap-3 mb-4 text-white/70 text-[1rem]">
              <span className="text-[1.2rem]">📱</span><span>+91 89505 10445</span>
            </div>
            <div className="flex items-center gap-3 mb-4 text-white/70 text-[1rem]">
              <span className="text-[1.2rem]">✉️</span><span>sonueditor.590@gmail.com</span>
            </div>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, x: 60 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          >
            <div className="flex flex-col gap-4">
              <input type="text" className="px-5 py-3.5 bg-glass border border-glass-border text-white font-rajdhani text-[1rem] outline-none transition-all duration-300 clip-path-btn placeholder:text-white/30 placeholder:tracking-[.08em] focus:border-red/50 focus:shadow-[0_0_20px_rgba(255,44,44,.1)]" placeholder="Your Name" />
              <input type="tel" className="px-5 py-3.5 bg-glass border border-glass-border text-white font-rajdhani text-[1rem] outline-none transition-all duration-300 clip-path-btn placeholder:text-white/30 placeholder:tracking-[.08em] focus:border-red/50 focus:shadow-[0_0_20px_rgba(255,44,44,.1)]" placeholder="Phone Number" />
              <input type="email" className="px-5 py-3.5 bg-glass border border-glass-border text-white font-rajdhani text-[1rem] outline-none transition-all duration-300 clip-path-btn placeholder:text-white/30 placeholder:tracking-[.08em] focus:border-red/50 focus:shadow-[0_0_20px_rgba(255,44,44,.1)]" placeholder="Email Address" />
              <select className="px-5 py-3.5 bg-glass border border-glass-border text-white/70 font-rajdhani text-[1rem] outline-none transition-all duration-300 clip-path-btn focus:border-red/50 focus:shadow-[0_0_20px_rgba(255,44,44,.1)] appearance-none">
                <option value="" className="bg-[#1a0808]">Select Your Goal</option>
                <option className="bg-[#1a0808]">Weight Loss</option>
                <option className="bg-[#1a0808]">Muscle Building</option>
                <option className="bg-[#1a0808]">Personal Training</option>
                <option className="bg-[#1a0808]">Fat Loss Program</option>
              </select>
              <textarea className="px-5 py-3.5 bg-glass border border-glass-border text-white font-rajdhani text-[1rem] outline-none transition-all duration-300 clip-path-btn placeholder:text-white/30 placeholder:tracking-[.08em] focus:border-red/50 focus:shadow-[0_0_20px_rgba(255,44,44,.1)] min-h-[120px] resize-y" placeholder="Tell us about your fitness goals..."></textarea>
              <button 
                onClick={() => window.open('https://wa.me/918950510445?text=Hi%20I%20want%20to%20join%20the%20gym')}
                className="hover-target p-4 bg-gradient-to-br from-red to-orange border-none text-white font-rajdhani text-[1rem] font-bold tracking-[.15em] uppercase cursor-none clip-path-btn-lg transition-all duration-300 shadow-[0_0_30px_rgba(255,44,44,.4)] hover:brightness-115 hover:-translate-y-[2px]"
              >
                Send Message via WhatsApp →
              </button>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
